PENNYTRACK - ANDROID PROJECT

Features:
- Dark premium finance dashboard
- Add, edit and delete income/expense records
- Categories and date tracking
- Monthly budget tracking
- Category spending chart and summary
- CSV export
- Offline local storage (WebView localStorage)

APK BUILD:
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the generated APK location.

Important:
This environment does not have the Android SDK or Gradle installed, so it cannot compile/sign an APK here. The complete Android Studio project is included. No account or internet connection is needed for the app's normal features. Records are stored locally on the device; export CSV backups before clearing app data.

CLOUD BUILD OPTION (NO ANDROID STUDIO REQUIRED ON YOUR PHONE):
A GitHub Actions workflow is included at .github/workflows/build-apk.yml.
1. Upload this project folder to a GitHub repository (main branch).
2. Open the repository's Actions tab and run "Build PennyTrack APK" (or wait for the push build).
3. Open the completed workflow run and download the "PennyTrack-debug-APK" artifact.
4. Extract the artifact and install app-debug.apk on your Android device. Android may ask you to allow installation from the browser/files app.

The cloud workflow builds a debug APK for testing. It is not a Play Store release/signing setup.
